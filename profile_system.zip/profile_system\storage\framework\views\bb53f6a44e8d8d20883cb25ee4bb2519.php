<p><?php echo e($user->name); ?> — <?php echo e($user->email); ?></p>

<?php if(isset($user->bio)): ?>
    <small>Has bio</small>
<?php else: ?>
    <small>No bio yet</small>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\profile_system\resources\views/partials/user-row.blade.php ENDPATH**/ ?>