<div class="card">

    <div class="card-header">
        <?php echo e($header); ?>

    </div>

    <div class="card-body">
        <?php echo e($slot); ?>

    </div>

    <?php if(isset($footer)): ?>
        <div class="card-footer">
            <?php echo e($footer); ?>

        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\profile_system\resources\views/components/card.blade.php ENDPATH**/ ?>