<button <?php echo e($attributes->merge(['class' => 'btn btn-primary'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\xampp\htdocs\profile_system\resources\views/components/button.blade.php ENDPATH**/ ?>