<div class="alert alert-<?php echo e($type); ?>">
    <strong><?php echo e($message); ?></strong>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\xampp\htdocs\profile_system\resources\views/components/alert.blade.php ENDPATH**/ ?>