

<?php $__env->startSection('title', 'Gallery'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <h1 class="text-center mb-4" style="font-weight: 600;">My Photo Gallery</h1>
    <p class="text-center mb-4">Here are 15 of my favorite photos</p>

    <div class="row g-1"> 
        <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 col-sm-4 col-md-2-4 p-1"> 
            <div class="gallery-card">
                <img src="<?php echo e(asset('images/' . $photo)); ?>" alt="Photo <?php echo e($loop->iteration); ?>" class="img-fluid">
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<style>

.gallery-card {
    width: 100%;
    padding-top: 100%;
    position: relative;
    overflow: hidden;
}

.gallery-card img {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
}

@media (min-width: 992px) {
    .col-md-2-4 {
        flex: 0 0 20%;
        max-width: 20%;
    }
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mysite\resources\views/gallery.blade.php ENDPATH**/ ?>